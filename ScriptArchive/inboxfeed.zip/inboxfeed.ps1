﻿###Code from http://poshcode.org/?show=669
# Creates an RSS feed
# Parameter input is for "site": Path, Title, Url, Description
# Pipeline input is for feed items: hashtable with Title, Link, Author, Description, and pubDate keys
Function New-RssFeed
{ 
	param (
	        $Path = "$( throw 'Path is a mandatory parameter.' )",
	        $Title = "Site Title",
	        $Url = "http://$( $env:computername )",
	        $Description = "Description of site"
	)
	Begin {
	        # feed metadata
	        $encoding = [System.Text.Encoding]::UTF8
	        $writer = New-Object System.Xml.XmlTextWriter( $Path, $encoding )
	        $writer.WriteStartDocument()
	        $writer.WriteStartElement( "rss" )
	        $writer.WriteAttributeString( "version", "2.0" )
	        $writer.WriteStartElement( "channel" )
	        $writer.WriteElementString( "title", $Title )
	        $writer.WriteElementString( "link", $Url )
	        $writer.WriteElementString( "description", $Description )
	}
	Process {
	        # Construct feed items
	        $writer.WriteStartElement( "item" )
	        $writer.WriteElementString( "title",    $_.title )
	        $writer.WriteElementString( "link",             $_.link )
	        $writer.WriteElementString( "author",   $_.author )
	        $writer.WriteStartElement( "description" )
	        $writer.WriteRaw( "<![CDATA[" ) # desc can contain HTML, so its escaped using SGML escape code
	        $writer.WriteRaw( $_.description )
	        $writer.WriteRaw( "]]>" )
	        $writer.WriteEndElement()
	        $writer.WriteElementString( "pubDate", $_.pubDate.toString( 'r' ) )
	        $writer.WriteElementString( "guid", $homePageUrl + "/" + [guid]::NewGuid() )
	        $writer.WriteEndElement()
	}
	End {
	        $writer.WriteEndElement()
	        $writer.WriteEndElement()
	        $writer.WriteEndDocument()
	        $writer.Close()
	}
}
### end code from http://poshcode.org/?show=669

## Get the Mailbox to Access from the 1st commandline argument

$MailboxName = $args[0]

## Load Managed API dll  
Add-Type -Path "C:\Program Files\Microsoft\Exchange\Web Services\1.2\Microsoft.Exchange.WebServices.dll"  
  
## Set Exchange Version  
$ExchangeVersion = [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::Exchange2010_SP1  
  
## Create Exchange Service Object  
$service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService($ExchangeVersion)  
  
## Set Credentials to use two options are availible Option1 to use explict credentials or Option 2 use the Default (logged On) credentials  
  
#Credentials Option 1 using UPN for the windows Account  
$psCred = Get-Credential  
$creds = New-Object System.Net.NetworkCredential($psCred.UserName.ToString(),$psCred.GetNetworkCredential().password.ToString())  
$service.Credentials = $creds      
  
#Credentials Option 2  
#service.UseDefaultCredentials = $true  
  
## Choose to ignore any SSL Warning issues caused by Self Signed Certificates  
  
## Code From http://poshcode.org/624
## Create a compilation environment
$Provider=New-Object Microsoft.CSharp.CSharpCodeProvider
$Compiler=$Provider.CreateCompiler()
$Params=New-Object System.CodeDom.Compiler.CompilerParameters
$Params.GenerateExecutable=$False
$Params.GenerateInMemory=$True
$Params.IncludeDebugInformation=$False
$Params.ReferencedAssemblies.Add("System.DLL") | Out-Null

$TASource=@'
  namespace Local.ToolkitExtensions.Net.CertificatePolicy{
    public class TrustAll : System.Net.ICertificatePolicy {
      public TrustAll() { 
      }
      public bool CheckValidationResult(System.Net.ServicePoint sp,
        System.Security.Cryptography.X509Certificates.X509Certificate cert, 
        System.Net.WebRequest req, int problem) {
        return true;
      }
    }
  }
'@ 
$TAResults=$Provider.CompileAssemblyFromSource($Params,$TASource)
$TAAssembly=$TAResults.CompiledAssembly

## We now create an instance of the TrustAll and attach it to the ServicePointManager
$TrustAll=$TAAssembly.CreateInstance("Local.ToolkitExtensions.Net.CertificatePolicy.TrustAll")
[System.Net.ServicePointManager]::CertificatePolicy=$TrustAll

## end code from http://poshcode.org/624
  
## Set the URL of the CAS (Client Access Server) to use two options are availbe to use Autodiscover to find the CAS URL or Hardcode the CAS to use  
  
#CAS URL Option 1 Autodiscover  
$service.AutodiscoverUrl($MailboxName,{$true})  
"Using CAS Server : " + $Service.url   
   
#CAS URL Option 2 Hardcoded  
  
#$uri=[system.URI] "https://casservername/ews/exchange.asmx"  
#$service.Url = $uri    
  
## Optional section for Exchange Impersonation  
  
#$service.ImpersonatedUserId = new-object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress, $MailboxName) 

# Bind to the Contacts Folder

$folderid= new-object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Inbox,$MailboxName)   
$Inbox = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($service,$folderid)
$psPropset = new-object Microsoft.Exchange.WebServices.Data.PropertySet([Microsoft.Exchange.WebServices.Data.BasePropertySet]::FirstClassProperties)  
#Define ItemView to retrive just 50 Items    
$ivItemView =  New-Object Microsoft.Exchange.WebServices.Data.ItemView(50)    
$fiItems = $service.FindItems($Inbox.Id,$ivItemView)    
[Void]$service.LoadPropertiesForItems($fiItems,$psPropset)  
$feedItems = @()
foreach($Item in $fiItems.Items){    
	 "processing Item " + $Item.Subject
	 $PostItem = @{}
	 $PostItem.Add("Title",$Item.Subject)
	 $PostItem.Add("Author",$Item.Sender.Address)
	 $PostItem.Add("pubDate",$Item.DateTimeReceived)
	 $PostItem.Add("link",("https://" + $service.Url.Host +  "/owa/" + $Item.WebClientReadFormQueryString))
	 $PostItem.Add("description",$Item.Body.Text)
	 $feedItems += $PostItem       
}    
$feedItems | New-RssFeed -path "c:\temp\Inboxfeed.xml" -title ($MailboxName + " Inbox")


